
#ifndef __DEFINE_H
#define __DEFINE_H
/******************************************************************************
Typedef definitions
******************************************************************************/
typedef struct _time_t 
{
	uint8_t centisecond;
	uint8_t second;
	uint8_t minute;
} time_t;

typedef struct _data
{
	unsigned int number_centisecond;
	unsigned int number_second;
	unsigned int number_minute;
	unsigned int datanumber;
}data_memory;
/******************************************************************************
Macro definitions
******************************************************************************/
#define PORT7 *(volatile unsigned char *) 0xFFF07
#define PORTMODE7 *(volatile unsigned char *) 0xFFF27


#endif
/******************************************************************************
End of file
******************************************************************************/
