
#ifndef __COUNT_TIME_H
#define __COUNT_TIME_H

#include "r_macro.h"  /* System macro and standard type definition */
#include "define.h"

//void wait(unsigned long M);
void time_count(void);
void save_chuoi(void);
void first_record(void);
void last_record(void);


#endif
/******************************************************************************
End of file
******************************************************************************/
