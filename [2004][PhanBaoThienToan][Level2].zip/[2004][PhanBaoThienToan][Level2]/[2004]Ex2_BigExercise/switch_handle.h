
#ifndef __SWITCH_HANDLE_H
#define __SWITCH_HANDLE_H

#include "r_macro.h"  /* System macro and standard type definition */
#include "define.h"

//void wait(unsigned long M);

void detectSW(void);
void sw_handle(void);
void update_LCD(void);
void check_strengthlen(void);
void save_string(void);
void save(int n);
void display_6(void);
void display_6_21(void);
void display_21_100(void);
void display_crollup(void);
void display_crolldown(void);
#endif
/******************************************************************************
End of file
******************************************************************************/
