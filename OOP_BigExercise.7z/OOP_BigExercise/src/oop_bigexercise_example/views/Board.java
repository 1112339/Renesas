package oop_bigexercise_example.views;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Canvas;
import oop_bigexercise_example.model.SquareRx;

import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class Board extends Composite implements IBoard {
	SquareRx[][] squares;
    final int MARGIN_CELLS = 1; // margin range for the boundary of board game
    private int SIZE=20;
    private Canvas canvas;
    private int turn = 1; // 1: player 1; 2: player 2
    private boolean hasWiner = false; // true or false
    private CaroGameView parentView;
	static int cell_sizeX = 1;
    static int cell_sizeY = 1;
    private int boundary =0;
    
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Board(Composite parent, int style) {
		super(parent, style);
		setLayout(new FillLayout(SWT.HORIZONTAL));

		parentView = CaroGameView.getIntance();
		initBoardGame(SIZE);
		
		canvas = new Canvas(this, SWT.NONE);
		canvas.setSize(parent.getSize());
		canvas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
				int x = (int)(e.x / cell_sizeX) - 1;
				int y = (int)(e.y / cell_sizeY) - 1;
				
				if (!squares[x][y].isOccupied())
				{
					squares[x][y].setOccupied(true);
					squares[x][y].setTurn(turn);
					
					if (hasWiner())
						parentView.setWiner(turn);
					else
					{
						if (turn == 1)
							turn = 2; // turn of PLAYER 2
						else 
							turn = 1; // turn of PLAYER 1
						
						// update the new turn
						parentView.setTurnPlayer(turn);
					}
				}
			}
			@Override
			public void mouseUp(MouseEvent e) {
				canvas.redraw();
			}
		});
		canvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent e) {
				GC gc = e.gc;
				gc.setLineWidth(2);
		        int w = ((Canvas)e.widget).getSize().x;
		        int h = ((Canvas)e.widget).getSize().y;
		        cell_sizeX = (int)(w / (SIZE + MARGIN_CELLS*2));
		        cell_sizeY = (int)(h / (SIZE + MARGIN_CELLS*2));
		        // Draw vertical grid lines.
		        gc.setForeground(new org.eclipse.swt.graphics.Color(e.display, new RGB(255, 0, 0)));
		        int x0 = MARGIN_CELLS*cell_sizeX;
		        int y0 = MARGIN_CELLS*cell_sizeY;
		        for (int i = 0; i <= SIZE; i++) {
		            int x = x0 + i*cell_sizeX;
		            gc.drawLine(x , y0, x, y0 + SIZE*cell_sizeY);
		        }
		        // Draw horizontal grid lines.
		        for (int i = 0; i <= SIZE; i++) {
		            int y = y0 + i*cell_sizeY;
		            gc.drawLine(x0 , y, x0 + SIZE*cell_sizeX, y);
		        }
		        // Draw icon of players
		        for(int i = 0; i < SIZE; i++) {
		            for(int j = 0; j < SIZE; j++) {
		                if (squares[i][j].isOccupied())
		                {  				
		                	drawIcons(gc, squares[i][j].getTurn(), (i + MARGIN_CELLS) * cell_sizeX, (j + MARGIN_CELLS) * cell_sizeY);
		                }
		            }
		        }
		        gc.dispose();
				//canvas.redraw();
			}
		});
	}
	
	private void drawIcons(GC gc, int turn, int x, int y)
	{
		if (turn == 1)
		{
	        gc.setForeground(new org.eclipse.swt.graphics.Color(canvas.getDisplay(), new RGB(0, 255, 0)));
			gc.drawOval(x + cell_sizeX/10, y + cell_sizeY/10, cell_sizeX * 8/10, cell_sizeY* 8/10);
		}
		else
		{	
	        gc.setForeground(new org.eclipse.swt.graphics.Color(canvas.getDisplay(), new RGB(0, 0, 255)));
			gc.drawLine(x + cell_sizeX/10, y + cell_sizeY/10, x + cell_sizeX*9/10, y + cell_sizeY*9/10);
			gc.drawLine(x + cell_sizeX/10, y + cell_sizeY*9/10, x + cell_sizeX*9/10, y + cell_sizeY/10);
		}
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	@Override
	public void initBoardGame(int size)
	{
		int ROWS = size;
        int COLS = size;
        squares = new SquareRx[ROWS][COLS];
        for(int i = 0; i < ROWS; i++) {
            for(int j = 0; j < COLS; j++) {
                squares[i][j] = new SquareRx(i, j);
            }
        }
	}

	@Override
	public boolean hasWiner() {
		// call to check winer
		checkWiner();
		return hasWiner;
	}

	/**
	 * Check the winer after finishing player's turn
	 * @return 
	 */
	private void checkWiner() {
		hasWiner = false; //TODO: need to implement
		int check1=0;
		int check2=0;
		int check3=0;
		int check4=0;
		int check5=0;
		int check6=0;
		int check7=0;
		int check8=0;
		int check9=0;
		int check10=0;
		
		int current_row1=0;
		int previous_row1=0;
		int current_row2=0;
		int previous_row2=0;
		int current_row3=0;
		int previous_row3=0;
		int current_row4=0;
		int previous_row4=0;
		int current_row5=0;
		int previous_row5=0;
		int current_row6=0;
		int previous_row6=0;

		int current_column1=0;
		int previous_column1=0;
		int current_column2=0;
		int previous_column2=0;
		int current_column3=0;
		int previous_column3=0;
		int current_column4=0;
		int previous_column4=0;
		int current_column5=0;
		int previous_column5=0;
		int current_column6=0;
		int previous_column6=0;

		
		

		
        if(boundary==0){
	    for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            		if (squares[i][j].getTurn()==1){
            		previous_row1 = current_row1;
            		current_row1=j;
            		if (((current_row1-previous_row1)==1)||previous_row1==0){
            		check1 = check1 +1;
            		}
            		if (check1==5){
            			hasWiner = true;
            			check1=0;
            			turn=1;
            		}
            		}
            		}
            }
            
	
	
	   //check_row_win2_X;
	    for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==2){
        		previous_row2 = current_row2;
        		current_row2=j;
        		if ((current_row2-previous_row2)==1||previous_row2==0){
        		check2 = check2 +1;
        		}
        		if (check2==5){
        			hasWiner = true;
        			check2=0;
        			turn=2;
        		}
        		}
	    }	
	    }
	
		//check_column_win1_O;
	    for(int j = 0; j< SIZE; j++) { 	
            for(int i = 0; i < SIZE; i++) {
            	if (squares[i][j].getTurn()==1) {
            		previous_column1 = current_column1;
            		current_column1=i;
            		if ((current_column1-previous_column1)==1||previous_column1==0){
            		check3 = check3 +1;}
            		if (check3==5){
            			hasWiner = true;
            			check3=0;
            			turn=1;
            		}
            		}
            }
            }
	    
	  //check_column_win2_X;
	    for(int j = 0; j < SIZE; j++) { 	
            for(int i = 0; i < SIZE; i++) {
            	if (squares[i][j].getTurn()==2){
        		previous_column2 = current_column2;
        		current_column2=i;
        		if ((current_column2-previous_column2)==1||previous_column2==0){
        		check4 = check4 +1;
        		}
        		if (check4==5){
        			hasWiner = true;
        			check4=0;
        			turn=2;
        		}
        		}
	    }	
	    }
	  
	    //check_cross_win1_O;
	    for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==1) {
            		previous_column3 = current_column3;
            		previous_row3 = current_row3;
            		current_column3=j;
            		current_row3=i;
            	int dif1= Math.abs(current_row3-previous_row3) ;
            	int dif2= Math.abs(current_column3-previous_column3) ;
            		if ((dif1==1&&dif2==1)||(previous_row3==0&&previous_column3==0)){
            		check5 = check5 +1;
            		}
            		if (check5==5){
            			hasWiner = true;
            			check5=0;
            			turn=1;
            		}
            		}
            }
            }
	    
	    //check_cross_win2_x;
	    for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==2) {
            		previous_column4 = current_column4;
            		previous_row4 = current_row4;
            		current_column4=j;
            		current_row4=i;
            	int dif3= Math.abs(current_row4-previous_row4) ;
            	int dif4= Math.abs(current_column4-previous_column4) ;
            		if ((dif3==1&&dif4==1)||(previous_row4==0&&previous_column4==0)){
            		check6 = check6 +1;
            		}
            		if (check6==5){
            			hasWiner = true;
            			check6=0;
            			turn=2;
            		}
            		}
            }
            }
	    
	    }
        else { 
        	
		//Check_boundary_row_win1_0;
		for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==2) {
            		previous_row2 = current_row2;
            		current_row2=j;
            		if ((current_row2-previous_row2)==6){
            		check2 = check2+1;
            }
            	}
            }
		}
		
		//check_row_win1_O;
		for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==1) {
            		previous_row1 = current_row1;
            		current_row1=j;
            		if ((current_row1-previous_row1)==1||previous_row1==0){
            		check1 = check1 +1;
            		if (check1==5&&check2==0){
            			hasWiner = true;
            			check1=0;
            			check2=0;
            			turn=1;
            			break;
            		}
            		}
            	}
            }
            	}
		
		//Check_boundary_row_win2_x;
		for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==1) {
            		previous_row3 = current_row3;
            		current_row3=j;
            		if ((current_row3-previous_row3)==6){
            		check3 = check3+1;
            }
            	}
            }
		}
		//check_row_win2_x;
		for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==2) {
            		previous_row4 = current_row4;
            		current_row4=j;
            		if ((current_row4-previous_row4)==1||previous_row4==0){
            		check4 = check4 +1;
            		if (check4==5&&check3==0){
            			hasWiner = true;
            			check4=0;
            			check3=0;
            			turn=2;
            		}
            		}
            	}
            }
		
	    }
		
		//Check_boundary_column_win1_0;
		for(int j = 0; j< SIZE; j++) { 	
            for(int i = 0; i < SIZE; i++) {
            	if (squares[i][j].getTurn()==2) {
            		previous_column1 = current_column1;
            		current_column1=i;
            		if ((current_column1-previous_column1)==6){
            		check5 = check5+1;
            }
            	}
            }
		}
		//check_column_win1_0;
		for(int j = 0; j < SIZE; j++) { 	
            for(int i = 0; i < SIZE; i++) {
            	if (squares[i][j].getTurn()==1) {
            		previous_column2 = current_column2;
            		current_column2=i;
            		if ((current_column2-previous_column2)==1||previous_column2==0){
            		check6 = check6 +1;
            		if (check6==5&&check5==0){
            			hasWiner = true;
            			check6=0;
            			check5=0;
            			turn=1;
            		}
            		}
            	}
            }
		
	    }
		
		//Check_boundary_column_win2_x;
		for(int j = 0; j< SIZE; j++) { 	
            for(int i = 0; i < SIZE; i++) {
            	if (squares[i][j].getTurn()==1) {
            		previous_column3 = current_column3;
            		current_column3=i;
            		if ((current_column3-previous_column3)==6){
            		check7 = check7+1;
            }
            	}
            }
		}
		//check_column_win2_x;
		for(int j = 0; j < SIZE; j++) { 	
            for(int i = 0; i < SIZE; i++) {
            	if (squares[i][j].getTurn()==2) {
            		previous_column4 = current_column4;
            		current_column4=i;
            		if ((current_column4-previous_column4)==1||previous_column4==0){
            		check8 = check8 +1;
            		if (check8==5&&check7==0){
            			hasWiner = true;
            			check8=0;
            			check7=0;
            			turn=2;
            		}
            		}
            	}
            }
		
	    }
		
	    //check_boundary_cross_win1_O;
	    for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==1) {
            		previous_column6 = current_column6;
            		previous_row6 = current_row6;
            		current_column6=j;
            		current_row6=i;
            	int dif1= Math.abs(current_row6-previous_row6) ;
            	int dif2= Math.abs(current_column6-previous_column6) ;
            		if ((dif1==1&&dif2==1)||(previous_row6==0&&previous_column6==0)){
            		check10 = check10 +1;
            		}
            		if (check10==5){
            			if(squares[i+1][j+1].getTurn()==2&&squares[i-5][j-5].getTurn()==2){
            			check10=0;
            			//turn=1;	
            			hasWiner = false;
            			break;
            			}else {
            				hasWiner = true;
                			check10=0;
                			turn=1;	
            			}
            			
            		}
         
            		}
            }
            }
		
	  //check_boundary_cross_win2_x;
	    for(int i = 0; i < SIZE; i++) { 	
            for(int j = 0; j < SIZE; j++) {
            	if (squares[i][j].getTurn()==2) {
            		previous_column5 = current_column5;
            		previous_row5 = current_row5;
            		current_column5=j;
            		current_row5=i;
            	int dif1= Math.abs(current_row5-previous_row5) ;
            	int dif2= Math.abs(current_column5-previous_column5) ;
            		if ((dif1==1&&dif2==1)||(previous_row5==0&&previous_column5==0)){
            		check9 = check9 +1;
            		}
            		if (check9==5){
            			if(squares[i+1][j+1].getTurn()==1&&squares[i-5][j-5].getTurn()==1){	
            			check9=0;
            			//turn=2;
            			hasWiner = false;
            			break;
            			}else {
            				hasWiner = true;
                			check9=0;
                			turn=2;	
            			}
            			
            		}
         
            		}
            }
            }
	    
        }   
	}
            	
            	
            		
            		
          
		
	

    @Override
    public int getTurn() {
		return turn;
	}
    
    public void setSize(int t){
    	this.SIZE=t;
    }
    
    public void draw_table()
    {
    	canvas.redraw();
    }
    
    public void setBoundary(int a) {
		this.boundary=a;
	}
    	
  
}
