package oop_bigexercise_example.views;


import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.*;

import org.eclipse.jface.action.*;
import org.eclipse.ui.*;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;


/**
 * This sample class demonstrates how to plug-in a new
 * workbench view. The view shows data obtained from the
 * model. The sample creates a dummy model on the fly,
 * but a real implementation would connect to the model
 * available either in this or another plug-in (e.g. the workspace).
 * The view is connected to the model using a content provider.
 * <p>
 * The view uses a label provider to define how model
 * objects should be presented in the view. Each
 * view can present the same model objects using
 * different labels and icons, if needed. Alternatively,
 * a single label provider can be shared between views
 * in order to ensure that objects of the same type are
 * presented in the same way everywhere.
 * <p>
 */

public class CaroGameView extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "oop_bigexercise_example.views.CaroGameView";

	private Action action1;
	private Action action2;	
	private Label playerLabel;
	private Cursor currentCursor;
	private Board board;
	 
	private static CaroGameView instance;
	
	public static CaroGameView getIntance()
	{
		return instance;
	}
	
	/**
	 * The constructor.
	 */
	public CaroGameView() {
		instance = this;
	}

	/**
	 * This is a callback that will allow us
	 * to create the viewer and initialize it.
	 */
	public void createPartControl(Composite parent) {
		
		SashForm sashForm = new SashForm(parent, SWT.NONE);
		
		Composite leftComposite = new Composite(sashForm, SWT.NONE);
		leftComposite.setLayout(new FillLayout(SWT.HORIZONTAL));
		board = new Board(leftComposite, SWT.NONE);
		
		Composite rightComposite = new Composite(sashForm, SWT.NONE);
		
		Label lblPlayerStatus = new Label(rightComposite, SWT.NONE);
		lblPlayerStatus.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblPlayerStatus.setBounds(10, 22, 178, 30);
		lblPlayerStatus.setText("Player status:");
		
		playerLabel = new Label(rightComposite, SWT.NONE);
		playerLabel.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_RED));
		playerLabel.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		playerLabel.setBounds(20, 58, 168, 25);
		playerLabel.setText("Player 1");
		
		final Combo combo = new Combo(rightComposite, SWT.NONE);
		combo.setItems(new String[] {"10", "20", "30", "40", "50"});
		combo.setBounds(109, 143, 56, 23);
		
		final Combo combo_1 = new Combo(rightComposite, SWT.NONE);
		combo_1.setItems(new String[] {"0", "1"});
		combo_1.setBounds(109, 186, 56, 23);
		
		Button btnNewGame = new Button(rightComposite, SWT.NONE);
		btnNewGame.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			String sizetable= combo.getText();
			int size_of_table= Integer.parseInt(sizetable);
			String win_condition= combo_1.getText();
		    int check_boundary= Integer.parseInt(win_condition);
			board.setBoundary(check_boundary);
			board.setSize(size_of_table);
			board.initBoardGame(size_of_table);
			board.draw_table();
		
			}
		});
		btnNewGame.setBounds(55, 286, 75, 25);
		btnNewGame.setText("New Game");
		
		Label lblNewLabel = new Label(rightComposite, SWT.NONE);
		lblNewLabel.setBounds(83, 146, 20, 20);
		lblNewLabel.setText("Size");
		

		Label lblCheckBoundary = new Label(rightComposite, SWT.NONE);
		lblCheckBoundary.setText("Check Boundary");
		lblCheckBoundary.setBounds(10, 189, 91, 15);
		sashForm.setWeights(new int[] {2, 1});

		
		makeActions();
		hookContextMenu();
		contributeToActionBars();
	}

	private void hookContextMenu() {
		MenuManager menuMgr = new MenuManager("#PopupMenu");
		menuMgr.setRemoveAllWhenShown(true);
		menuMgr.addMenuListener(new IMenuListener() {
			public void menuAboutToShow(IMenuManager manager) {
				CaroGameView.this.fillContextMenu(manager);
			}
		});
		//Menu menu = menuMgr.createContextMenu(viewer.getControl());
		//viewer.getControl().setMenu(menu);
		//getSite().registerContextMenu(menuMgr, viewer);
	}

	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
		fillLocalToolBar(bars.getToolBarManager());
	}

	private void fillLocalPullDown(IMenuManager manager) {
		manager.add(action1);
		manager.add(new Separator());
		manager.add(action2);
	}

	private void fillContextMenu(IMenuManager manager) {
		manager.add(action1);
		manager.add(action2);
		// Other plug-ins can contribute there actions here
		manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
	}
	
	private void fillLocalToolBar(IToolBarManager manager) {
		manager.add(action1);
		manager.add(action2);
	}

	private void makeActions() {
		action1 = new Action() {
			public void run() {
				showMessage("Action 1 executed");
			}
		};
		action1.setText("Action 1");
		action1.setToolTipText("Action 1 tooltip");
		action1.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
			getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		action2 = new Action() {
			public void run() {
				showMessage("Action 2 executed");
			}
		};
		action2.setText("Action 2");
		action2.setToolTipText("Action 2 tooltip");
		action2.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
	}

	private void showMessage(String message) {
			
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
	}
	
	/**
	 * Update the current player information
	 * @param turn Turn of current player
	 */
	public void setTurnPlayer(int turn)
	{
		String text = turn == 1? "Player 1": "Player 2";
		playerLabel.setText(text);
		if (turn == 1)
			currentCursor = new Cursor(board.getDisplay(), SWT.CURSOR_ARROW);
		else 
			currentCursor = new Cursor(board.getDisplay(), SWT.CURSOR_HAND);
		board.setCursor(currentCursor);
	}
	
	/**
	 * Update the current player information
	 * @param turn Turn of current player
	 */
	public void setWiner(int turn)
	{
		String text = turn == 1? "Player 1 won": "Player 2 won";
		playerLabel.setText(text);
	}
}
